﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace _3.Filmek_nyilvantartasa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static List<Class1> orak = new List<Class1>();
        string[] beolvas;

        public MainWindow()
        {
            InitializeComponent();
            beolvas = File.ReadAllLines("filmek.txt");
            bool firstLineSkipped = false;
            foreach (var item in beolvas)
            {
                if (firstLineSkipped)
                {
                    firstLineSkipped = true;
                    continue;
                }

                string[] filmAdatok = item.Split(';');
                if (filmAdatok.Length >= 5)
                {
                    string teljesInformacio = $" {filmAdatok[0]}, {filmAdatok[1]},  {filmAdatok[2]}, {filmAdatok[3]}, {filmAdatok[4]}";
                    lbx.Items.Add(teljesInformacio);
                }
            }

        }

        private void ListBox_SelectionChanged()
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            lbx.Items.Clear();
            MessageBox.Show("Veszely eszlelve!");


        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            lbx.Items.Clear(); 

            string keresettCim = cim.Text.Trim();
            string keresettRendezo = rendezo.Text.Trim();
            string keresettFoSzereplo = foszereplo.Text.Trim();
            string keresettEv = ev.Text.Trim();
            string keresettAdathordozo = adat.SelectedItem != null ?adat.SelectedItem.ToString() : "";

            foreach (var item in beolvas)
            {
                string[] filmAdatok = item.Split(';');

                if (filmAdatok.Length >= 5 &&
                    (string.IsNullOrEmpty(keresettCim) || filmAdatok[0].ToLower().Contains(keresettCim.ToLower())) &&
                    (string.IsNullOrEmpty(keresettRendezo) || filmAdatok[1].ToLower().Contains(keresettRendezo.ToLower())) &&
                    (string.IsNullOrEmpty(keresettFoSzereplo) || filmAdatok[2].ToLower().Contains(keresettFoSzereplo.ToLower())) &&
                    (string.IsNullOrEmpty(keresettEv) || filmAdatok[3] == keresettEv) &&
                    (string.IsNullOrEmpty(keresettAdathordozo) || filmAdatok[4].ToLower() == keresettAdathordozo.ToLower()))
                {
                    string teljesInformacio = $" {filmAdatok[0]},  {filmAdatok[1]}, {filmAdatok[2]}, {filmAdatok[3]}, {filmAdatok[4]}";
                    lbx.Items.Add(teljesInformacio);
                }
            }
        }
            private void ev_TextChanged(object sender, TextChangedEventArgs e)
            {

            }

        private void kolcson_Click(object sender, RoutedEventArgs e)
        {
            lbx.Foreground = Brushes.Red;
            MessageBox.Show("Biztos kolcson szeretned adni?");
        }
    }
    }