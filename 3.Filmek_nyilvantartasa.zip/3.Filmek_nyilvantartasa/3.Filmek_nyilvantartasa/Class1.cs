﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Filmek_nyilvantartasa
{
    class Class1
    {
        public string cim, ev, foszereplo, adat, rendezo;
        public Class1(string egysor)
        {
            string[] db = egysor.Split(';');
            cim = db[0];
            ev = db[1];
            foszereplo = db[2];
            adat = db[3];
            rendezo = db[4];
        }

    }
}
